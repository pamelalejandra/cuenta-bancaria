class Cuenta_bancaria:
    def __init__ (self, tasa_interes, balance):
        self.tasa_interes = tasa_interes
        self.balance = balance
        self.balance_cuenta = balance
    
    def deposito (self, amount):
        self.balance_cuenta += amount
        return self
    
    def retiro(self,amount):
        self.balance_cuenta -= amount
        if self.balance_cuenta <= 100:
            print ('Fondos insuficientes: Su saldo es menor a $100 se le cobrará una tarifa de $5')
            self.balance_cuenta -= 5
        return self
    
    def mostrar_info_cuenta (self):
        print('Balance:'+' '+'$'+ str(self.balance_cuenta))
        return self
    
    def generar_interes (self):
        if self.balance_cuenta > 0 :
            self.balance_cuenta += self.balance_cuenta*(self.tasa_interes/100)
        return self
    
Cuenta1 = Cuenta_bancaria(10,200)
Cuenta2 = Cuenta_bancaria(5,500)
Cuenta1.deposito(10).deposito(20).deposito(30).retiro(50).generar_interes().mostrar_info_cuenta()
Cuenta2.deposito(2000).deposito(3000).retiro(50).retiro(100).retiro(60).retiro(90).generar_interes().mostrar_info_cuenta()